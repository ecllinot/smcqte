// src/main/java/net/smc/qte/mixin/InGameHudAccessor.java
package net.smc.qte.mixin;

import net.minecraft.class_2561;
import net.minecraft.class_329;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_329.class)
public interface InGameHudAccessor {

    @Accessor("title")
    class_2561 getTitle();

    @Accessor("subtitle")
    class_2561 getSubtitle();

    @Accessor("titleRemainTicks")
    int getTitleRemainTicks();
}